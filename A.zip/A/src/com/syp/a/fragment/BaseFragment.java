package com.syp.a.fragment;

import android.support.v4.app.Fragment;
import android.view.View;

public abstract class BaseFragment extends Fragment {
	
	public abstract void checkData();
	public abstract void init_click(View v);
	
	
	

}
